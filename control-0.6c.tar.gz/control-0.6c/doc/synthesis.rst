Control System Synthesis
************************

.. autofunction:: control.lqr
.. autofunction:: control.place
