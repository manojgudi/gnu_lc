.. Python-Control documentation master file, created by
   sphinx-quickstart on Thu Jan  6 09:49:36 2011.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Python Control User's Manual
============================

Welcome to the Python Control Systems Library (python-control) User's
Manual.  This manual describes the python-control package, including
all of the functions defined in the package and examples showing how
to use the package.

Contents:

.. toctree::
   :maxdepth: 2
   
   intro
   modules
   class_strings
   matlab_strings
   examples

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
