Python-Control Functions
************************

.. toctree::

   creation
   bdalg_strings
   analysis
   freqplot
   timeresp
   synthesis
   modsimp_strings
   utilities
