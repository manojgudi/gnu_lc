Model Simplification Tools
**************************

.. autofunction:: control.balred
.. autofunction:: control.hsvd
.. autofunction:: control.modred
