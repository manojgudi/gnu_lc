Time Domain Simulation
**********************

Time responses
==============
.. autofunction:: control.forced_response
.. autofunction:: control.initial_response
.. autofunction:: control.step_response

Phase portraits
===============
.. autofunction:: phaseplot.phase_plot
.. autofunction:: phaseplot.box_grid
