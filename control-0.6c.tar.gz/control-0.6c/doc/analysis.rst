Control System Analysis
***********************

.. autofunction:: control.acker
.. autofunction:: control.ctrb
.. autofunction:: control.care
.. autofunction:: control.dare
.. autofunction:: control.dlyap
.. autofunction:: control.dcgain
.. autofunction:: control.evalfr
.. autofunction:: control.gram
.. autofunction:: control.lyap
.. autofunction:: control.freqresp
.. autofunction:: control.margin
.. autofunction:: control.markov
.. autofunction:: control.obsv
.. autofunction:: control.phase_crossover_frequencies
.. autofunction:: control.pole
.. autofunction:: control.root_locus
.. autofunction:: control.stability_margins
.. autofunction:: control.zero

