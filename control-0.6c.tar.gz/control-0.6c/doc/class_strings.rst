Python-Control Classes
********************** 

LTI System Class
================
.. automodule:: lti
   :members:

State Space Class
=================
.. automodule:: statesp
   :members:

Transfer Function Class
=======================
.. automodule:: xferfcn
   :members:

FRD Class
=========
.. automodule:: frdata
   :members:
