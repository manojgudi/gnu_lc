Frequency Domain Plotting
*************************

.. toctree::

Plotting routines
=================
.. autofunction:: control.bode_plot
.. autofunction:: control.nyquist_plot
.. autofunction:: control.gangof4_plot
.. autofunction:: control.nichols_plot

Utility functions
=================
.. autofunction:: freqplot.default_frequency_range
