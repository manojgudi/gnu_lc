Block Diagram Algebra
*********************

.. toctree::

.. autofunction:: control.feedback
.. autofunction:: control.negate
.. autofunction:: control.parallel
.. autofunction:: control.series
